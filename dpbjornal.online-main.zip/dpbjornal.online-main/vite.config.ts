import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { tanstackStart } from "@tanstack/react-start/plugin/vite";
import tailwindcss from "@tailwindcss/vite";
import netlify from "@netlify/vite-plugin-tanstack-start";

/**
 * Configuração do Vite para o projeto TanStack Start com React e Tailwind CSS.
 *
 * Plugins inclusos:
 * - tanstackStart: SSR, server functions e roteamento baseado em arquivo
 * - react: Suporte a JSX e Fast Refresh
 * - tailwindcss: Utilitários CSS via plugin oficial do Vite
 * - netlify: Configura o build para deploy no Netlify (Functions + Edge)
 *
 * Nota: vite-tsconfig-paths foi substituído pelo suporte nativo do Vite 8
 * via resolve.tsconfigPaths, eliminando o aviso de depreciação.
 */
export default defineConfig({
  plugins: [
    tanstackStart(),
    react(),
    tailwindcss(),
    netlify(),
  ],
  resolve: {
    tsconfigPaths: true,
  },
  server: {
    port: 5173,
    strictPort: false,
  },
});
