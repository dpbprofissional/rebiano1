# Guia para Agentes de IA

## Visão Geral do Projeto

Este é um projeto **TanStack Start** com **React**, **TypeScript** e **Tailwind CSS**. A aplicação é um sistema de administração de artigos/notícias com autenticação e gerenciamento de conteúdo.

## Estrutura do Projeto

```
src/
├── components/       # Componentes React reutilizáveis
├── routes/          # Rotas da aplicação (file-based routing)
├── lib/             # Utilitários e funções auxiliares
├── hooks/           # Custom React hooks
├── styles/          # Estilos globais
└── server.ts        # Entrada do servidor SSR
```

## Principais Tecnologias

- **Framework**: TanStack Start (React 19)
- **Roteamento**: TanStack Router
- **Styling**: Tailwind CSS v4
- **UI Components**: Radix UI
- **Formulários**: React Hook Form + Zod
- **Banco de Dados**: Neon (PostgreSQL serverless)
- **Build Tool**: Vite

## Boas Práticas

1. **Tipagem**: Sempre use TypeScript com tipos explícitos
2. **Componentes**: Mantenha componentes pequenos e reutilizáveis
3. **Validação**: Use Zod para validação de dados
4. **Performance**: Aproveite o file-based routing do TanStack Router
5. **Erros**: Use o sistema de tratamento de erros existente em `src/lib/error-reporting.ts`

## Scripts Disponíveis

- `npm run dev` - Inicia o servidor de desenvolvimento
- `npm run build` - Cria build de produção
- `npm run preview` - Visualiza o build de produção
- `npm run lint` - Executa ESLint
- `npm run format` - Formata código com Prettier

## Dicas para Modificações

- Evite reescrever histórico de git já publicado
- Mantenha a branch em estado funcional
- Teste mudanças localmente antes de fazer commit
- Siga as convenções de código existentes
