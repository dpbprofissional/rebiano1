import { createStart, createMiddleware } from "@tanstack/react-start";

import { renderErrorPage } from "./lib/error-page";

const errorMiddleware = createMiddleware().server(async ({ next }) => {
  try {
    return await next();
  } catch (error) {
    // Re-lança erros HTTP (como redirecionamentos e 404) sem transformar
    if (error != null && typeof error === "object" && "statusCode" in error) {
      throw error;
    }
    // Loga o erro completo no servidor para facilitar diagnóstico
    console.error("[server] Erro não capturado:", error);
    return new Response(renderErrorPage(), {
      status: 500,
      headers: { "content-type": "text/html; charset=utf-8" },
    });
  }
});

export const startInstance = createStart(() => ({
  requestMiddleware: [errorMiddleware],
}));
