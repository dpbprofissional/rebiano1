import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { SiteHeader, SiteFooter } from "@/components/site-chrome";

export const Route = createFileRoute("/contato")({
  head: () => ({
    meta: [
      { title: "Contato — DPB Jornal Investigativo" },
      { name: "description", content: "Envie denúncias, informações confidenciais ou sugestões de pauta. Sigilo garantido." },
      { property: "og:title", content: "Contato — DPB Jornal Investigativo" },
      { property: "og:description", content: "Envie denúncias e sugestões de pauta com sigilo garantido." },
    ],
  }),
  component: ContatoPage,
});

function ContatoPage() {
  const [sent, setSent] = useState(false);
  const [form, setForm] = useState({ nome: "", email: "", mensagem: "" });

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const subject = encodeURIComponent(`Contato do site — ${form.nome || "Anônimo"}`);
    const body = encodeURIComponent(`${form.mensagem}\n\n— ${form.nome} (${form.email})`);
    window.location.href = `mailto:contato@dpbjornal.online?subject=${subject}&body=${body}`;
    setSent(true);
  };

  return (
    <div className="min-h-screen flex flex-col">
      <SiteHeader />
      <main className="flex-1">
        <div className="mx-auto max-w-4xl px-5 py-16 sm:py-24">
          <div className="flex flex-col items-center text-center mb-12">
            <h1 className="font-serif text-4xl sm:text-6xl font-bold leading-tight">Contato</h1>
            <p className="mt-6 text-xl text-muted-foreground max-w-xl leading-relaxed font-serif italic">
              Tem uma denúncia ou sugestão de pauta? Envie-nos uma mensagem de forma segura e confidencial.
            </p>
            <div className="w-20 h-1 bg-brand mt-8" />
          </div>

          <div className="mx-auto max-w-xl">
            <div className="mb-12 border border-border rounded-xl p-8 bg-surface shadow-sm">
              <h2 className="font-serif text-2xl font-bold mb-4">Sigilo e segurança</h2>
              <p className="text-muted-foreground leading-relaxed">
                Garantimos total sigilo sobre a identidade de nossas fontes. Todas as informações
                recebidas são tratadas com a máxima confidencialidade e responsabilidade, em conformidade
                com a legislação de proteção de fontes jornalísticas.
              </p>
              <div className="mt-8 pt-6 border-t border-border flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <span className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">E-mail profissional:</span>
                <a className="text-brand font-bold hover:underline" href="mailto:contato@dpbjornal.online">
                  contato@dpbjornal.online
                </a>
              </div>
            </div>

            <form onSubmit={onSubmit} className="space-y-8 bg-surface p-8 sm:p-10 rounded-xl border border-border shadow-sm">
              <div className="grid gap-8 sm:grid-cols-2">
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase tracking-[0.2em] text-muted-foreground ml-1">Nome</label>
                  <input
                    required
                    value={form.nome}
                    onChange={(e) => setForm({ ...form, nome: e.target.value })}
                    placeholder="Seu nome"
                    className="w-full rounded-lg border border-border bg-background px-4 py-3 text-sm focus:border-brand focus:ring-1 focus:ring-brand focus:outline-none transition-all"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase tracking-[0.2em] text-muted-foreground ml-1">E-mail</label>
                  <input
                    required
                    type="email"
                    value={form.email}
                    onChange={(e) => setForm({ ...form, email: e.target.value })}
                    placeholder="seu@email.com"
                    className="w-full rounded-lg border border-border bg-background px-4 py-3 text-sm focus:border-brand focus:ring-1 focus:ring-brand focus:outline-none transition-all"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-[0.2em] text-muted-foreground ml-1">Mensagem</label>
                <textarea
                  required
                  rows={6}
                  value={form.mensagem}
                  onChange={(e) => setForm({ ...form, mensagem: e.target.value })}
                  placeholder="Descreva sua denúncia ou sugestão com o máximo de detalhes..."
                  className="w-full rounded-lg border border-border bg-background px-4 py-3 text-sm focus:border-brand focus:ring-1 focus:ring-brand focus:outline-none transition-all resize-none"
                />
              </div>
              <button
                type="submit"
                className="w-full rounded-lg bg-brand py-4 text-[11px] font-black uppercase tracking-[0.3em] text-brand-foreground transition-all hover:opacity-90 hover:shadow-lg hover:shadow-brand/20 active:scale-[0.98]"
              >
                Enviar mensagem
              </button>
              {sent && (
                <div className="flex items-center justify-center gap-2 text-brand animate-pulse">
                  <span className="w-2 h-2 rounded-full bg-brand" />
                  <p className="text-[10px] font-black uppercase tracking-widest">Abrindo seu cliente de e-mail…</p>
                </div>
              )}
            </form>
          </div>
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}
