import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";
import { useEffect, type ReactNode } from "react";

import appCss from "../styles.css?url";
import { reportError, setupGlobalErrorHandlers } from "../lib/error-reporting";

/**
 * Componente exibido quando a página não é encontrada (404).
 */
function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="font-serif text-7xl font-black text-foreground">404</h1>
        <h2 className="mt-4 font-serif text-xl font-semibold text-foreground">
          Página não encontrada
        </h2>
        <p className="mt-2 text-sm text-muted-foreground">
          A página que você procura não existe ou foi movida.
        </p>
        <div className="mt-6">
          <Link
            to="/"
            className="inline-flex items-center justify-center rounded-md bg-brand px-4 py-2 text-sm font-semibold text-brand-foreground transition-colors hover:opacity-90"
          >
            Voltar à home
          </Link>
        </div>
      </div>
    </div>
  );
}

/**
 * Componente exibido quando um erro não capturado ocorre na aplicação.
 * Oferece opções para tentar novamente ou voltar à home.
 */
function ErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  const router = useRouter();
  
  useEffect(() => {
    // Relata o erro para análise
    reportError(error, { 
      boundary: "tanstack_root_error_component",
      errorName: error.name,
    });
  }, [error]);

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-xl font-semibold tracking-tight text-foreground">
          Algo deu errado
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Desculpe, ocorreu um erro inesperado. Você pode tentar novamente ou voltar à página inicial.
        </p>
        
        {/* Exibe a mensagem de erro em desenvolvimento */}
        {process.env.NODE_ENV === "development" && (
          <div className="mt-4 rounded-md bg-red-50 p-3 text-left">
            <p className="text-xs font-mono text-red-700 break-words">
              {error.message}
            </p>
          </div>
        )}
        
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          <button
            onClick={() => {
              router.invalidate();
              reset();
            }}
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Tentar novamente
          </button>
          <a
            href="/"
            className="inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent"
          >
            Ir para home
          </a>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "DPB — Jornal Investigativo" },
      { name: "description", content: "Informação apurada. Verdade documentada." },
      { property: "og:title", content: "DPB — Jornal Investigativo" },
      { property: "og:description", content: "Informação apurada. Verdade documentada." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [
      { rel: "stylesheet", href: appCss },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,500;0,700;0,900;1,700&family=Inter:wght@400;500;600;700&display=swap",
      },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

/**
 * Shell raiz da aplicação.
 * Renderiza a estrutura HTML básica.
 */
function RootShell({ children }: { children: ReactNode }) {
  useEffect(() => {
    // Configura handlers globais de erro no cliente
    setupGlobalErrorHandlers();
  }, []);

  return (
    <html lang="pt-BR">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

/**
 * Componente raiz da aplicação.
 * Fornece o QueryClient para toda a árvore de componentes.
 */
function RootComponent() {
  const { queryClient } = Route.useRouteContext();

  return (
    <QueryClientProvider client={queryClient}>
      {/* Outlet é obrigatório: renderiza as rotas aninhadas aqui */}
      <Outlet />
    </QueryClientProvider>
  );
}
