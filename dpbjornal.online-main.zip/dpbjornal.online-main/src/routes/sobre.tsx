import { createFileRoute } from "@tanstack/react-router";
import { SiteHeader, SiteFooter } from "@/components/site-chrome";

export const Route = createFileRoute("/sobre")({
  head: () => ({
    meta: [
      { title: "Sobre — DPB Jornal Investigativo" },
      { name: "description", content: "Quem somos: portal independente dedicado ao jornalismo investigativo de interesse público." },
      { property: "og:title", content: "Sobre — DPB Jornal Investigativo" },
      { property: "og:description", content: "Portal independente dedicado ao jornalismo investigativo de interesse público." },
    ],
  }),
  component: SobrePage,
});

function SobrePage() {
  return (
    <div className="min-h-screen flex flex-col">
      <SiteHeader />
      <main className="flex-1">
        <div className="mx-auto max-w-4xl px-5 py-16 sm:py-24">
          <div className="flex flex-col items-center text-center mb-16">
            <h1 className="font-serif text-4xl sm:text-6xl font-bold leading-tight max-w-3xl">
              Sobre o DPB Jornal Investigativo
            </h1>
            <div className="w-20 h-1 bg-brand mt-8" />
          </div>
          <div className="mx-auto max-w-2xl space-y-8 text-lg leading-relaxed text-muted-foreground font-serif">
            <p>
              O <strong>DPB Jornal Investigativo</strong> é um portal independente dedicado à prática
              do jornalismo investigativo de interesse público. Nossa missão é produzir reportagens
              aprofundadas, análises documentadas e relatórios baseados em evidências, com compromisso
              absoluto com a verdade e a transparência.
            </p>
            <p>
              Acreditamos que o acesso à informação de qualidade é um pilar fundamental da democracia.
              Por isso, investimos tempo e rigor na apuração de cada fato, na verificação de cada
              documento e na contextualização de cada dado antes de publicá-los.
            </p>
            <p>
              Nosso trabalho é orientado por princípios éticos sólidos: independência editorial,
              imparcialidade, responsabilidade e respeito ao contraditório. Não respondemos a
              interesses políticos, econômicos ou corporativos — nossa única obrigação é com o leitor
              e com a verdade dos fatos.
            </p>
            <p>
              Todas as reportagens publicadas passam por um processo rigoroso de checagem e
              verificação. Fontes são protegidas conforme a legislação vigente, e documentos são
              analisados com critério antes de qualquer divulgação.
            </p>
            <p>
              O DPB Jornal Investigativo está comprometido com o fortalecimento da cultura de
              transparência e prestação de contas no Brasil. Se você tem informações de interesse
              público, entre em contato conosco de forma segura e confidencial.
            </p>
          </div>
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}
