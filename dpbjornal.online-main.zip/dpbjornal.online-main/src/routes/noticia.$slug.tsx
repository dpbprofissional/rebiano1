import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { queryOptions, useSuspenseQuery } from "@tanstack/react-query";
import { getArticleBySlug } from "@/lib/articles.functions";
import { SiteHeader, SiteFooter } from "@/components/site-chrome";

const articleQuery = (slug: string) =>
  queryOptions({
    queryKey: ["article", slug],
    queryFn: () => getArticleBySlug({ data: { slug } }),
  });

export const Route = createFileRoute("/noticia/$slug")({
  loader: async ({ params, context }) => {
    const data = await context.queryClient.ensureQueryData(articleQuery(params.slug));
    if (!data) throw notFound();
    return data;
  },
  head: ({ loaderData }) => ({
    meta: loaderData
      ? [
          { title: `${loaderData.title} — DPB` },
          { name: "description", content: loaderData.subtitle },
          { property: "og:title", content: loaderData.title },
          { property: "og:description", content: loaderData.subtitle },
          { property: "og:image", content: loaderData.cover_url },
          { property: "og:type", content: "article" },
        ]
      : [],
  }),
  component: ArticlePage,
  notFoundComponent: () => (
    <div className="min-h-screen flex flex-col">
      <SiteHeader />
      <div className="flex-1 flex items-center justify-center p-6 text-center">
        <div>
          <h1 className="font-serif text-3xl">Matéria não encontrada</h1>
          <Link to="/" className="text-brand underline mt-4 inline-block">
            Voltar à home
          </Link>
        </div>
      </div>
      <SiteFooter />
    </div>
  ),
  errorComponent: ({ error }) => (
    <div className="min-h-screen flex items-center justify-center p-6 text-center">
      <p className="text-muted-foreground text-sm">{error.message}</p>
    </div>
  ),
});

function ArticlePage() {
  const { slug } = Route.useParams();
  const { data: article } = useSuspenseQuery(articleQuery(slug));
  if (!article) return null;

  return (
    <div className="min-h-screen flex flex-col">
      <SiteHeader />
      <main className="flex-1">
        <div className="mx-auto max-w-4xl px-5 py-12 sm:py-20">
          <Link to="/" className="text-[10px] font-black uppercase tracking-widest text-muted-foreground hover:text-brand transition-colors flex items-center gap-2 mb-10">
            <span className="text-lg">←</span> Voltar para o início
          </Link>
          
          <div className="flex flex-col items-center text-center mb-12">
            <span className="inline-block bg-brand text-brand-foreground text-[10px] font-black uppercase tracking-[0.2em] px-4 py-2 rounded-sm mb-6">
              {article.category}
            </span>
            <h1 className="font-serif text-4xl sm:text-6xl font-bold leading-[1.1] max-w-4xl">
              {article.title}
            </h1>
            <p className="text-xl sm:text-2xl text-muted-foreground mt-8 leading-relaxed max-w-2xl font-serif italic">
              {article.subtitle}
            </p>
            <div className="flex items-center gap-4 text-[11px] font-bold uppercase tracking-widest text-muted-foreground mt-10">
              <span>{new Date(article.published_at).toLocaleDateString("pt-BR", {
                day: "numeric",
                month: "long",
                year: "numeric",
              })}</span>
              <span className="w-1.5 h-1.5 rounded-full bg-brand" />
              <span>Por {article.author}</span>
            </div>
          </div>

          {article.cover_url && (
            <div className="relative aspect-[16/9] w-full overflow-hidden rounded-xl shadow-2xl mb-16">
              <img
                src={article.cover_url}
                alt={article.title}
                className="absolute inset-0 h-full w-full object-cover"
              />
            </div>
          )}

          <article className="mx-auto max-w-2xl font-serif text-xl leading-relaxed text-foreground/90 space-y-8 dropcap">
            {article.content.split(/\n{2,}/).map((para, i) => (
              <p 
                key={i} 
                className={`whitespace-pre-wrap ${i === 0 ? "first-letter:text-6xl first-letter:font-black first-letter:text-brand first-letter:mr-3 first-letter:float-left first-letter:leading-[0.8]" : ""}`}
              >
                {para}
              </p>
            ))}
          </article>
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}
