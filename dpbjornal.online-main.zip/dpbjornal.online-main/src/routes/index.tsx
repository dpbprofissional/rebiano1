import { createFileRoute, Link } from "@tanstack/react-router";
import { queryOptions, useSuspenseQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { listArticles } from "@/lib/articles.functions";
import { SiteHeader, SiteFooter } from "@/components/site-chrome";


const articlesQuery = queryOptions({
  queryKey: ["articles"],
  queryFn: () => listArticles(),
});

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "DPB — Jornal Investigativo" },
      { name: "description", content: "Informação apurada. Verdade documentada. Últimas investigações do DPB." },
      { property: "og:title", content: "DPB — Jornal Investigativo" },
      { property: "og:description", content: "Informação apurada. Verdade documentada." },
    ],
  }),
  loader: ({ context }) => context.queryClient.ensureQueryData(articlesQuery),
  component: Home,
  errorComponent: ({ error }) => (
    <div className="min-h-screen flex items-center justify-center p-6 text-center bg-background">
      <div className="max-w-lg">
        <h1 className="font-serif text-3xl font-bold text-foreground">Erro ao carregar</h1>
        <div className="mt-4 p-4 rounded-lg bg-destructive/10 border border-destructive/20 text-left">
          <p className="text-sm text-foreground font-medium">Detalhes do erro:</p>
          <p className="mt-1 text-xs font-mono text-muted-foreground break-words">{error.message}</p>
        </div>
        <p className="mt-6 text-sm text-muted-foreground leading-relaxed">
          Este erro geralmente ocorre devido a problemas na conexão com o banco de dados. 
          Se você é o administrador, verifique se a variável <code className="bg-muted px-1 rounded text-foreground">NEON_DATABASE_URL</code> está configurada corretamente no Netlify.
        </p>
        <div className="mt-8">
          <button 
            onClick={() => window.location.reload()}
            className="rounded-md bg-brand px-6 py-2 text-sm font-bold uppercase tracking-widest text-brand-foreground hover:opacity-90 transition-all"
          >
            Tentar Novamente
          </button>
        </div>
      </div>
    </div>
  ),
});

function formatDate(iso: string) {
  try {
    return new Date(iso).toLocaleDateString("pt-BR", {
      day: "numeric",
      month: "long",
      year: "numeric",
    });
  } catch {
    return "";
  }
}

function Home() {
  const { data: articles } = useSuspenseQuery(articlesQuery);
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState<string>("all");

  const categories = useMemo(() => {
    const set = new Set<string>();
    articles.forEach((a) => a.category && set.add(a.category));
    return ["all", ...Array.from(set)];
  }, [articles]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return articles.filter((a) => {
      if (category !== "all" && a.category !== category) return false;
      if (!q) return true;
      return (
        a.title.toLowerCase().includes(q) ||
        a.subtitle.toLowerCase().includes(q) ||
        a.author.toLowerCase().includes(q)
      );
    });
  }, [articles, query, category]);

  const [featured, ...rest] = filtered;

  return (
    <div className="min-h-screen flex flex-col">
      <SiteHeader />
      <main className="flex-1">
        <div className="mx-auto max-w-6xl px-5 pt-8">
          <div className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between border-b border-border/50 pb-6">
            <div className="relative w-full sm:max-w-xs">
              <input
                id="search-input"
                type="search"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Buscar matérias…"
                aria-label="Buscar matérias"
                className="w-full rounded-full border border-border bg-surface px-4 py-2 text-sm placeholder:text-muted-foreground focus:border-brand focus:ring-1 focus:ring-brand focus:outline-none transition-all"
              />
            </div>
            {categories.length > 1 && (
              <div className="flex flex-wrap items-center gap-2 overflow-x-auto pb-2 sm:pb-0 no-scrollbar">
                <span className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground mr-1 hidden lg:block">Filtros:</span>
                {categories.map((c) => (
                  <button
                    key={c}
                    type="button"
                    onClick={() => setCategory(c)}
                    className={`whitespace-nowrap rounded-full border px-4 py-1.5 text-[10px] font-bold uppercase tracking-wider transition-all ${
                      category === c
                        ? "border-brand bg-brand text-brand-foreground shadow-sm shadow-brand/20"
                        : "border-border bg-background text-muted-foreground hover:border-muted-foreground hover:text-foreground"
                    }`}
                  >
                    {c === "all" ? "Todas" : c}
                  </button>
                ))}
              </div>
            )}
          </div>



          {featured ? (
            <Link
              to="/noticia/$slug"
              params={{ slug: featured.slug }}
              className="group relative block overflow-hidden rounded-lg border border-border"
            >
              <div className="relative aspect-[16/10] sm:aspect-[21/9] w-full min-h-[400px]">
                {featured.cover_url ? (
                  <img
                    src={featured.cover_url}
                    alt={featured.title}
                    className="absolute inset-0 h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
                    loading="eager"
                  />
                ) : (
                  <div className="absolute inset-0 bg-surface" />
                )}

              </div>

            </Link>
          ) : articles.length === 0 ? (
            <div className="border border-border rounded-lg p-10 text-center text-muted-foreground">
              Nenhuma matéria publicada ainda.{" "}
              <Link to="/admin" className="text-brand underline">
                Acessar admin
              </Link>
            </div>
          ) : (
            <div className="border border-border rounded-lg p-10 text-center text-muted-foreground">
              Nenhuma matéria encontrada para sua busca.
            </div>
          )}

        </div>

        {rest.length > 0 && (
          <section id="investigacoes" className="mx-auto max-w-6xl px-5 mt-16 scroll-mt-24">
            <div className="flex items-end justify-between border-b border-border pb-4 mb-8">
              <h2 className="font-serif text-2xl sm:text-3xl font-bold">Últimas Investigações</h2>
            </div>
            <div className="flex flex-col divide-y divide-border border-y border-border">
              {rest.map((a) => (
                <Link
                  key={a.id}
                  to="/noticia/$slug"
                  params={{ slug: a.slug }}
                  className="group grid grid-cols-1 sm:grid-cols-[300px_1fr] gap-6 sm:gap-10 py-8 sm:py-12 items-center"
                >
                  <div className="aspect-[16/10] overflow-hidden rounded-lg bg-surface shadow-md">
                    {a.cover_url ? (
                      <img
                        src={a.cover_url}
                        alt={a.title}
                        loading="lazy"
                        className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
                      />
                    ) : (
                      <div className="h-full w-full flex items-center justify-center text-muted-foreground/20 font-serif text-4xl font-bold">DPB</div>
                    )}
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-2 mb-3">
                      <span className="text-[10px] font-black uppercase tracking-[0.2em] text-brand">
                        {a.category}
                      </span>
                      <span className="w-1 h-1 rounded-full bg-border" />
                      <span className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground">
                        {formatDate(a.published_at)}
                      </span>
                    </div>
                    <h3 className="font-serif text-2xl sm:text-3xl lg:text-4xl font-bold leading-tight group-hover:text-brand transition-colors decoration-brand/30 decoration-2 underline-offset-4 group-hover:underline">
                      {a.title}
                    </h3>
                    <p className="text-sm sm:text-base text-muted-foreground mt-4 line-clamp-2 sm:line-clamp-3 leading-relaxed">
                      {a.subtitle}
                    </p>
                    <div className="text-[11px] font-bold uppercase tracking-widest text-muted-foreground/80 mt-6 flex items-center gap-2">
                      <span className="italic">Por</span> {a.author}
                    </div>
                  </div>
                </Link>
              ))}
            </div>

          </section>
        )}
      </main>
      <SiteFooter />
    </div>
  );
}
