import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/sitemap.xml")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const url = new URL(request.url);
        const origin = url.origin;
        const { sql, ensureSchema } = await import("@/lib/db.server");
        let urls: Array<{ loc: string; lastmod?: string }> = [
          { loc: `${origin}/` },
        ];
        try {
          await ensureSchema();
          const rows = (await sql`SELECT slug, published_at FROM dpb_articles ORDER BY published_at DESC LIMIT 1000`) as Array<{
            slug: string;
            published_at: string | Date;
          }>;
          urls = urls.concat(
            rows.map((r) => ({
              loc: `${origin}/noticia/${r.slug}`,
              lastmod:
                typeof r.published_at === "string"
                  ? r.published_at
                  : new Date(r.published_at).toISOString(),
            })),
          );
        } catch (e) {
          console.error("[sitemap] db error", e);
        }
        const xml = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls
          .map(
            (u) =>
              `  <url><loc>${u.loc}</loc>${u.lastmod ? `<lastmod>${u.lastmod}</lastmod>` : ""}</url>`,
          )
          .join("\n")}\n</urlset>\n`;
        return new Response(xml, {
          headers: { "content-type": "application/xml; charset=utf-8" },
        });
      },
    },
  },
});
