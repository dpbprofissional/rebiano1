import { Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Search } from "lucide-react";

function formatToday() {
  try {
    return new Date().toLocaleDateString("pt-BR", {
      weekday: "long",
      day: "numeric",
      month: "long",
      year: "numeric",
    });
  } catch {
    return "";
  }
}

export function SiteHeader() {
  const [today, setToday] = useState("");
  useEffect(() => setToday(formatToday()), []);

  return (
    <>
      <div className="bg-brand text-brand-foreground">
        <div className="mx-auto max-w-6xl px-5 py-2 flex items-center justify-between gap-3 text-xs sm:text-sm font-medium tracking-wide">
          <span>Informação apurada. Verdade documentada.</span>
          <span className="hidden sm:inline opacity-90">{today}</span>
        </div>
      </div>
      <header className="border-b border-border">
        <div className="mx-auto max-w-6xl px-5 py-6 flex items-end justify-between gap-4">
          <Link to="/" className="block group">
            <div className="font-serif text-4xl sm:text-5xl font-black tracking-tighter leading-none group-hover:text-brand transition-colors">
              DPB
            </div>
            <div className="text-[10px] sm:text-xs uppercase tracking-[0.3em] text-muted-foreground mt-1.5 font-sans font-bold">
              Jornal Investigativo
            </div>
          </Link>
          <nav className="hidden md:flex items-center gap-8 text-[11px] font-black uppercase tracking-widest text-muted-foreground">
            <Link to="/" className="hover:text-brand transition-colors [&.active]:text-brand border-b-2 border-transparent [&.active]:border-brand pb-1">Início</Link>
            <Link to="/" hash="investigacoes" className="hover:text-brand transition-colors border-b-2 border-transparent pb-1">Investigações</Link>
            <Link to="/sobre" className="hover:text-brand transition-colors [&.active]:text-brand border-b-2 border-transparent [&.active]:border-brand pb-1">Sobre</Link>
            <Link to="/contato" className="hover:text-brand transition-colors [&.active]:text-brand border-b-2 border-transparent [&.active]:border-brand pb-1">Contato</Link>
            <button 
              type="button" 
              aria-label="Buscar" 
              className="hover:text-brand transition-colors"
              onClick={() => document.getElementById('search-input')?.focus()}
            >
              <Search className="h-4 w-4" />
            </button>
          </nav>
          <div className="md:hidden flex items-center gap-4">
            <button 
              type="button" 
              aria-label="Buscar" 
              className="text-muted-foreground"
              onClick={() => document.getElementById('search-input')?.focus()}
            >
              <Search className="h-5 w-5" />
            </button>
            {/* Mobile menu could be added here if needed, but keeping it simple for now */}
          </div>
        </div>
      </header>
    </>
  );
}

export function SiteFooter() {
  return (
    <footer className="bg-surface text-foreground mt-24 border-t border-border">
      <div className="mx-auto max-w-6xl px-5 py-16 grid gap-12 sm:grid-cols-2 lg:grid-cols-4">
        <div className="lg:col-span-2">
          <div className="font-serif text-3xl font-black tracking-tighter">DPB</div>
          <div className="text-[10px] uppercase tracking-[0.2em] text-brand font-bold mt-1">Jornal Investigativo</div>
          <p className="mt-6 text-sm text-muted-foreground max-w-sm leading-relaxed">
            Comprometidos com a verdade documentada e a informação apurada com rigor jornalístico. Nossa missão é trazer à luz o que está oculto.
          </p>
        </div>
        <div>
          <h4 className="text-[11px] font-black uppercase tracking-[0.2em] text-foreground mb-6">Navegação</h4>
          <ul className="space-y-4 text-sm text-muted-foreground">
            <li><Link to="/" className="hover:text-brand transition-colors">Início</Link></li>
            <li><Link to="/" hash="investigacoes" className="hover:text-brand transition-colors">Investigações</Link></li>
            <li><Link to="/sobre" className="hover:text-brand transition-colors">Sobre</Link></li>
            <li><Link to="/contato" className="hover:text-brand transition-colors">Contato</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="text-[11px] font-black uppercase tracking-[0.2em] text-foreground mb-6">Contato</h4>
          <p className="text-sm text-muted-foreground leading-relaxed">
            Tem uma denúncia ou sugestão de pauta?<br />
            <a href="mailto:contato@dpbjornal.online" className="text-brand hover:underline mt-2 inline-block font-medium">
              contato@dpbjornal.online
            </a>
          </p>
        </div>
      </div>
      <div className="border-t border-border/50">
        <div className="mx-auto max-w-6xl px-5 py-8 flex flex-col sm:flex-row justify-between items-center gap-4 text-[10px] font-bold uppercase tracking-widest text-muted-foreground/60">
          <span>© {new Date().getFullYear()} DPB — Todos os direitos reservados.</span>
          <div className="flex gap-6">
            <a href="/privacidade" className="hover:text-brand transition-colors">Privacidade</a>
            <a href="/termos" className="hover:text-brand transition-colors">Termos</a>
          </div>
        </div>
      </div>
    </footer>
  );
}

