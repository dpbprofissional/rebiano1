import { useState } from "react";

export type ArticleFormValue = {
  slug?: string;
  title: string;
  subtitle: string;
  summary: string;
  category: string;
  cover_url?: string;
  content: string;
  author: string;
};

export function ArticleForm({
  initial,
  submitting,
  onSubmit,
  submitLabel,
}: {
  initial?: Partial<ArticleFormValue>;
  submitting?: boolean;
  submitLabel: string;
  onSubmit: (v: ArticleFormValue) => void | Promise<void>;
}) {
  const [v, setV] = useState<ArticleFormValue>({
    slug: initial?.slug ?? "",
    title: initial?.title ?? "",
    subtitle: initial?.subtitle ?? "",
    summary: initial?.summary ?? "",
    category: initial?.category ?? "Investigação",
    cover_url: initial?.cover_url ?? "",
    content: initial?.content ?? "",
    author: initial?.author ?? "Redação DPB",
  });

  const [imagePreview, setImagePreview] = useState<string | null>(
    initial?.cover_url ? initial.cover_url : null
  );

  function set<K extends keyof ArticleFormValue>(k: K, val: ArticleFormValue[K]) {
    setV((prev) => ({ ...prev, [k]: val }));
  }

  function handleImageUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const dataUrl = event.target?.result as string;
        setImagePreview(dataUrl);
        set("cover_url", dataUrl);
      };
      reader.readAsDataURL(file);
    }
  }

  function handleImageUrlChange(url: string) {
    set("cover_url", url);
    if (url) {
      setImagePreview(url);
    }
  }

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        onSubmit(v);
      }}
      className="space-y-5 max-w-2xl"
    >
      <Field label="Título">
        <input
          required
          value={v.title}
          onChange={(e) => set("title", e.target.value)}
          className="input"
        />
      </Field>
      <Field label="Subtítulo / chamada">
        <textarea
          required
          rows={2}
          value={v.subtitle}
          onChange={(e) => set("subtitle", e.target.value)}
          className="input resize-y"
        />
      </Field>
      <Field label="Resumo">
        <textarea
          required
          rows={2}
          value={v.summary}
          onChange={(e) => set("summary", e.target.value)}
          placeholder="Resumo breve do artigo para exibição em listas"
          className="input resize-y"
        />
      </Field>
      <div className="grid sm:grid-cols-2 gap-5">
        <Field label="Categoria">
          <input
            required
            value={v.category}
            onChange={(e) => set("category", e.target.value)}
            className="input"
          />
        </Field>
        <Field label="Autor">
          <input
            required
            value={v.author}
            onChange={(e) => set("author", e.target.value)}
            className="input"
          />
        </Field>
      </div>
      <Field label="Imagem de capa (opcional)">
        <div className="space-y-3">
          <div className="flex gap-2">
            <input
              type="file"
              accept="image/*"
              onChange={handleImageUpload}
              className="input flex-1"
            />
          </div>
          <div className="text-xs text-muted-foreground">
            ou insira uma URL da imagem:
          </div>
          <input
            type="url"
            value={v.cover_url || ""}
            onChange={(e) => handleImageUrlChange(e.target.value)}
            placeholder="https://..."
            className="input"
          />
          {imagePreview && (
            <div className="mt-3 rounded-md overflow-hidden border border-border">
              <img
                src={imagePreview}
                alt="Preview"
                className="w-full h-40 object-cover"
              />
            </div>
          )}
        </div>
      </Field>
      <Field label="Slug (opcional — gerado a partir do título se vazio)">
        <input
          value={v.slug}
          onChange={(e) => set("slug", e.target.value)}
          placeholder="exemplo-de-slug"
          className="input"
        />
      </Field>
      <Field label="Conteúdo">
        <textarea
          required
          rows={10}
          value={v.content}
          onChange={(e) => set("content", e.target.value)}
          className="input resize-y font-serif text-base"
        />
      </Field>
      <button
        type="submit"
        disabled={submitting}
        className="bg-brand text-brand-foreground font-semibold px-5 py-2.5 rounded-md hover:opacity-90 disabled:opacity-50"
      >
        {submitting ? "Salvando..." : submitLabel}
      </button>

      <style>{`
        .input {
          width: 100%;
          background: var(--color-surface);
          border: 1px solid var(--color-border);
          border-radius: 0.5rem;
          padding: 0.55rem 0.75rem;
          outline: none;
        }
        .input:focus { border-color: var(--color-brand); }
      `}</style>
    </form>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="text-sm font-medium block mb-1.5">{label}</span>
      {children}
    </label>
  );
}
