import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

/**
 * Mescla classes CSS do Tailwind com suporte a sobrescrita de estilos.
 * Combina `clsx` para lógica condicional com `twMerge` para resolver conflitos.
 * 
 * @param inputs - Classes CSS e valores condicionais
 * @returns String com classes CSS mescladas
 * 
 * @example
 * cn("px-2 py-1", isActive && "bg-blue-500", "px-4") // "py-1 bg-blue-500 px-4"
 */
export function cn(...inputs: ClassValue[]): string {
  return twMerge(clsx(inputs));
}

/**
 * Formata uma data para o padrão brasileiro (DD/MM/YYYY).
 * 
 * @param date - Data a ser formatada
 * @returns String formatada ou string vazia se data inválida
 * 
 * @example
 * formatDate(new Date("2024-06-24")) // "24/06/2024"
 */
export function formatDate(date: Date | string | null | undefined): string {
  if (!date) return "";
  
  try {
    const d = new Date(date);
    if (isNaN(d.getTime())) return "";
    
    return d.toLocaleDateString("pt-BR", {
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
    });
  } catch {
    return "";
  }
}

/**
 * Trunca um texto para um comprimento máximo, adicionando reticências.
 * 
 * @param text - Texto a ser truncado
 * @param maxLength - Comprimento máximo
 * @returns Texto truncado com reticências se necessário
 * 
 * @example
 * truncateText("Hello World", 5) // "Hello..."
 */
export function truncateText(text: string, maxLength: number = 100): string {
  if (!text || text.length <= maxLength) return text;
  return `${text.slice(0, maxLength)}...`;
}

/**
 * Gera um slug a partir de um texto (para URLs).
 * Remove caracteres especiais, converte para minúsculas e substitui espaços.
 * 
 * @param text - Texto a ser convertido em slug
 * @returns Slug formatado
 * 
 * @example
 * slugify("Hello World!") // "hello-world"
 */
export function slugify(text: string): string {
  return text
    .toLowerCase()
    .trim()
    .replace(/[^\w\s-]/g, "")
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-");
}

/**
 * Valida um email usando regex simples.
 * 
 * @param email - Email a ser validado
 * @returns true se email é válido, false caso contrário
 * 
 * @example
 * isValidEmail("user@example.com") // true
 */
export function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

/**
 * Capitaliza a primeira letra de uma string.
 * 
 * @param text - Texto a ser capitalizado
 * @returns Texto com primeira letra maiúscula
 * 
 * @example
 * capitalize("hello") // "Hello"
 */
export function capitalize(text: string): string {
  if (!text) return "";
  return text.charAt(0).toUpperCase() + text.slice(1);
}

/**
 * Delay assíncrono em milissegundos.
 * Útil para simulações de carregamento ou debouncing.
 * 
 * @param ms - Milissegundos a aguardar
 * @returns Promise que resolve após o tempo especificado
 * 
 * @example
 * await delay(1000); // Aguarda 1 segundo
 */
export function delay(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
