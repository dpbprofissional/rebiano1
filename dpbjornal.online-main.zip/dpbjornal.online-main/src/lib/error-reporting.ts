/**
 * Tipos para relatório de erros
 */
export interface ErrorContext {
  [key: string]: unknown;
}

export interface ErrorReport {
  message: string;
  stack?: string;
  context: ErrorContext;
  timestamp: string;
  route?: string;
}

/**
 * Converte um erro desconhecido para uma mensagem de string legível.
 * 
 * @param error - Erro a ser convertido
 * @returns String com mensagem de erro
 */
function getErrorMessage(error: unknown): string {
  if (error instanceof Error) {
    return error.message;
  }
  if (typeof error === "string") {
    return error;
  }
  return JSON.stringify(error);
}

/**
 * Converte um erro desconhecido para um objeto Error.
 * 
 * @param error - Erro a ser convertido
 * @returns Objeto Error
 */
function normalizeError(error: unknown): Error {
  if (error instanceof Error) {
    return error;
  }
  return new Error(getErrorMessage(error));
}

/**
 * Relata um erro para o console com contexto adicional.
 * Funciona tanto no servidor quanto no cliente.
 * 
 * @param error - Erro a ser reportado
 * @param context - Contexto adicional (opcional)
 * 
 * @example
 * try {
 *   // código
 * } catch (error) {
 *   reportError(error, { action: "fetchUser", userId: 123 });
 * }
 */
export function reportError(
  error: unknown,
  context: ErrorContext = {},
): void {
  const normalizedError = normalizeError(error);
  const errorMessage = getErrorMessage(error);
  
  const errorReport: ErrorReport = {
    message: errorMessage,
    stack: normalizedError.stack,
    context,
    timestamp: new Date().toISOString(),
    route: typeof window !== "undefined" ? window.location.pathname : undefined,
  };

  // Log no console
  if (typeof window === "undefined") {
    // Servidor
    console.error("[Server Error]", errorMessage, errorReport);
  } else {
    // Cliente
    console.error("[Client Error]", errorMessage, errorReport);
  }
}

/**
 * Relata um erro com severidade específica.
 * 
 * @param error - Erro a ser reportado
 * @param severity - Nível de severidade: "error" | "warning" | "info"
 * @param context - Contexto adicional (opcional)
 */
export function reportErrorWithSeverity(
  error: unknown,
  severity: "error" | "warning" | "info" = "error",
  context: ErrorContext = {},
): void {
  const normalizedError = normalizeError(error);
  const errorMessage = getErrorMessage(error);
  
  const logFn = severity === "error" ? console.error : 
                severity === "warning" ? console.warn : 
                console.info;

  logFn(`[${severity.toUpperCase()}]`, errorMessage, {
    timestamp: new Date().toISOString(),
    route: typeof window !== "undefined" ? window.location.pathname : undefined,
    stack: normalizedError.stack,
    ...context,
  });
}

/**
 * Captura e relata erros não capturados no cliente.
 * Deve ser chamado durante a inicialização da aplicação.
 */
export function setupGlobalErrorHandlers(): void {
  if (typeof window === "undefined") return;

  // Captura erros não capturados
  window.addEventListener("error", (event) => {
    reportError(event.error, {
      type: "uncaught_error",
      filename: event.filename,
      lineno: event.lineno,
      colno: event.colno,
    });
  });

  // Captura promessas rejeitadas
  window.addEventListener("unhandledrejection", (event) => {
    reportError(event.reason, {
      type: "unhandled_rejection",
    });
  });
}
