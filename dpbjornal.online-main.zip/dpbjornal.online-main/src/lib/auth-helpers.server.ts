import { useSession } from "@tanstack/react-start/server";
import { sessionConfig } from "./session.server";

export async function getSession() {
  return useSession<{ admin?: boolean; loggedInAt?: number }>(sessionConfig);
}

export async function requireAdmin() {
  const session = await getSession();
  if (!session.data.admin) {
    const error = new Error("Não autorizado") as any;
    error.statusCode = 401;
    throw error;
  }
}
