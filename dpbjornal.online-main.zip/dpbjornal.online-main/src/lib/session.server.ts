const isProduction = process.env.NODE_ENV === "production";

export const sessionConfig = {
  password: process.env.SESSION_SECRET ?? "dev-insecure-secret-change-me-please-32chars",
  name: "dpb_session",
  maxAge: 60 * 60 * 24 * 7, // 7 days
  cookie: {
    httpOnly: true,
    // Em produção usa sameSite: "none" + secure para cross-site; em dev usa "lax" sem secure
    sameSite: (isProduction ? "none" : "lax") as "none" | "lax",
    secure: isProduction,
    path: "/",
  },
};

export type SessionData = {
  admin?: boolean;
  loggedInAt?: number;
};
