# DPB — Jornal Investigativo

Sistema de administração de artigos e notícias para o jornal investigativo DPB, construído com **TanStack Start**, **React 19** e **TypeScript**.

## 🚀 Características

- ✅ **Autenticação segura** com gerenciamento de sessão
- ✅ **Editor de artigos** com interface intuitiva
- ✅ **Banco de dados** PostgreSQL serverless (Neon)
- ✅ **UI moderna** com Radix UI e Tailwind CSS
- ✅ **Validação de dados** com Zod
- ✅ **Roteamento** baseado em arquivo com TanStack Router
- ✅ **Tratamento de erros** robusto
- ✅ **SSR** (Server-Side Rendering) com TanStack Start

## 📋 Pré-requisitos

- **Node.js** 20+
- **npm** como gerenciador de pacotes
- Variáveis de ambiente configuradas (`.env`)

## 🛠️ Instalação

1. **Clone o repositório**
   ```bash
   git clone <repository-url>
   cd projeto
   ```

2. **Instale as dependências**
   ```bash
   npm install
   ```

3. **Configure as variáveis de ambiente**
   ```bash
   cp .env.example .env
   # Edite .env com suas credenciais
   ```

## 🏃 Executando o Projeto

### Desenvolvimento
```bash
npm run dev
# Acesse http://localhost:5173
```

### Build de Produção
```bash
npm run build
npm run preview
```

### Linting e Formatação
```bash
npm run lint      # Verifica código com ESLint
npm run format    # Formata código com Prettier
```

## 📁 Estrutura do Projeto

```
src/
├── components/           # Componentes React reutilizáveis
│   ├── ui/              # Componentes de UI (Radix UI)
│   └── ...              # Componentes customizados
├── routes/              # Rotas da aplicação (file-based routing)
│   ├── __root.tsx       # Rota raiz com layout global
│   ├── index.tsx        # Página inicial
│   ├── sobre.tsx        # Página sobre
│   ├── contato.tsx      # Página de contato
│   ├── noticia.$slug.tsx # Página de notícia individual
│   ├── admin.tsx        # Layout do admin
│   ├── admin.index.tsx  # Dashboard do admin
│   ├── admin.login.tsx  # Página de login
│   ├── admin.novo.tsx   # Criar novo artigo
│   └── admin.editar.$id.tsx # Editar artigo
├── lib/                 # Utilitários e funções auxiliares
│   ├── utils.ts         # Funções utilitárias gerais
│   ├── error-reporting.ts # Tratamento de erros
│   ├── auth.functions.ts  # Funções de autenticação
│   ├── auth-helpers.server.ts # Helpers de sessão server-side
│   ├── articles.functions.ts  # Funções de artigos (CRUD)
│   ├── db.server.ts     # Conexão com banco de dados Neon
│   ├── session.server.ts # Configuração de sessão
│   └── error-page.ts    # Página de erro HTML estática
├── hooks/               # Custom React hooks
├── styles.css           # Estilos globais
├── server.ts            # Entrada do servidor SSR
├── start.ts             # Bootstrap da aplicação
└── router.tsx           # Configuração do router
```

## 🔑 Variáveis de Ambiente

Crie um arquivo `.env` na raiz do projeto com as seguintes variáveis:

```env
# Banco de dados Neon (PostgreSQL serverless) — OBRIGATÓRIO
NEON_DATABASE_URL=postgresql://user:password@host/database?sslmode=require

# Autenticação do administrador
ADMIN_EMAIL=seu-email@exemplo.com
ADMIN_PASSWORD=sua-senha-segura

# Segredo para sessões (string aleatória longa)
SESSION_SECRET=string-aleatoria-com-pelo-menos-32-caracteres
```

> **Importante**: Nunca commite o arquivo `.env` no repositório. Ele já está no `.gitignore`.

## 🎨 Tecnologias Utilizadas

| Tecnologia | Versão | Propósito |
|-----------|--------|----------|
| React | 19.2.0 | Framework UI |
| TypeScript | 5.8.3 | Tipagem estática |
| TanStack Start | 1.167.50 | Meta-framework SSR |
| TanStack Router | 1.168.25 | Roteamento baseado em arquivo |
| Tailwind CSS | 4.2.1 | Utilitários CSS |
| Radix UI | Latest | Componentes acessíveis |
| React Hook Form | 7.71.2 | Gerenciamento de formulários |
| Zod | 3.24.2 | Validação de schema |
| Neon Serverless | 1.1.0 | PostgreSQL serverless |
| Vite | 8.0.16 | Build tool |

## 📝 Convenções de Código

### TypeScript
- Use tipos explícitos sempre que possível
- Evite `any`; use `unknown` se necessário
- Exporte tipos junto com implementações

### React
- Componentes funcionais com hooks
- Nomes de componentes em PascalCase
- Props tipadas com interfaces ou types

### Formatação
- ESLint + Prettier para formatação automática
- Print width: 100 caracteres
- Trailing commas em arrays/objetos
- Aspas duplas

## 🐛 Tratamento de Erros

O projeto possui um sistema robusto de tratamento de erros:

```typescript
import { reportError } from "@/lib/error-reporting";

try {
  // seu código
} catch (error) {
  reportError(error, { 
    action: "fetchData",
  });
}
```

## 🔐 Autenticação

A autenticação é gerenciada através de sessões seguras (cookie httpOnly). Veja `src/lib/auth.functions.ts` para mais detalhes.

## 🚀 Deploy

### Netlify (configurado)

O projeto está configurado para deploy no Netlify com SSR via Netlify Functions:

1. Conecte o repositório ao Netlify
2. Configure as variáveis de ambiente no painel do Netlify (**Site settings > Environment variables**):
   - `NEON_DATABASE_URL` — URL de conexão do banco Neon (obrigatório)
   - `ADMIN_EMAIL` — E-mail do administrador
   - `ADMIN_PASSWORD` — Senha do administrador
   - `SESSION_SECRET` — Chave secreta para sessões (string aleatória longa)
3. O build será executado automaticamente com `npm run build`
4. O diretório de publicação é `dist/client`
5. O servidor SSR é servido via `.netlify/v1/functions/server.mjs`

### Outras plataformas

Para deploy em outras plataformas com suporte a Node.js:

- **Railway / Heroku**: Remova o plugin `netlify()` do `vite.config.ts` e use `vite build` + `node dist/server/server.js`
- **Vercel**: Use o adaptador oficial do TanStack Start para Vercel

## 📄 Licença

Este projeto é propriedade privada do DPB — Jornal Investigativo.

---

**Última atualização**: Junho de 2025
