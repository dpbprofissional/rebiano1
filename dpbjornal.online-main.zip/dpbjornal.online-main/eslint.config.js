import js from "@eslint/js";
import eslintPluginPrettier from "eslint-plugin-prettier/recommended";
import globals from "globals";
import reactHooks from "eslint-plugin-react-hooks";
import reactRefresh from "eslint-plugin-react-refresh";
import tseslint from "typescript-eslint";

/**
 * Configuração ESLint para o projeto TanStack Start com React e TypeScript.
 * 
 * Inclui:
 * - Recomendações do ESLint e TypeScript
 * - Regras de React Hooks
 * - Integração com Prettier
 * - Validações customizadas para o projeto
 */
export default tseslint.config(
  { ignores: ["dist", ".output", ".vinxi", "node_modules", "build"] },
  {
    extends: [js.configs.recommended, ...tseslint.configs.recommended],
    files: ["**/*.{ts,tsx}"],
    languageOptions: {
      ecmaVersion: 2020,
      globals: globals.browser,
    },
    plugins: {
      "react-hooks": reactHooks,
      "react-refresh": reactRefresh,
    },
    rules: {
      ...reactHooks.configs.recommended.rules,
      
      // Regras customizadas
      "no-restricted-imports": [
        "error",
        {
          paths: [
            {
              name: "server-only",
              message:
                "TanStack Start não usa o pacote `server-only` do Next.js. Renomeie o módulo para `*.server.ts` ou marque com `@tanstack/react-start/server-only`.",
            },
          ],
        },
      ],
      
      // React Refresh
      "react-refresh/only-export-components": ["warn", { allowConstantExport: true }],
      
      // TypeScript
      "@typescript-eslint/no-unused-vars": "off",
      "@typescript-eslint/no-explicit-any": "warn",
      "@typescript-eslint/explicit-function-return-types": "off",
      "@typescript-eslint/explicit-module-boundary-types": "off",
      
      // Geral
      "no-console": ["warn", { allow: ["warn", "error", "info"] }],
      "prefer-const": "warn",
      "no-var": "error",
    },
  },
  eslintPluginPrettier,
);
